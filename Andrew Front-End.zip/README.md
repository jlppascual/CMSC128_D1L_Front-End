## CMSC128_D1L_Front-End
Repository for CMSC 128 D-1L Front-End Team

## Contributors
- Pascual, Jemimah @jlppascual
- Cervera, Leila @crvrlc
- Olo, Christian @ChristianLois
- Banglos, Thomas @BanglosT

## Branching
1. Run git checkout -b <role> command to create local branch. ex. git checkout -b backend or git checkout -b manager
2. Add files to your own local branch.
3. Create your own remote branch with the same branch name.
4. Push your local branch to your remote branch.
